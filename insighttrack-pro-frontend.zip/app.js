
const API = "http://localhost:8080/api";

async function login() {
  const email = document.getElementById("email").value;
  const senha = document.getElementById("senha").value;

  const res = await fetch(API + "/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, senha })
  });

  if (res.ok) {
    const data = await res.json();
    localStorage.setItem("token", data.token);
    localStorage.setItem("usuarioId", data.usuarioId);
    window.location.href = "dashboard.html";
  } else {
    document.getElementById("login-status").innerText = "Credenciais inválidas";
  }
}
