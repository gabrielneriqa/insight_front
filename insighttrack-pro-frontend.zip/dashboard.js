
const API = "http://localhost:8080/api";
const token = localStorage.getItem("token");

if (!token) window.location.href = "index.html";

async function criarCampanha() {
  const nome = document.getElementById("nomeCampanha").value;
  const usuarioId = localStorage.getItem("usuarioId");

  await fetch(API + "/campanhas", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
    body: JSON.stringify({ nome, usuarioId })
  });

  listarCampanhas();
}

async function listarCampanhas() {
  const usuarioId = localStorage.getItem("usuarioId");
  const res = await fetch(API + "/campanhas/usuario/" + usuarioId, {
    headers: { "Authorization": "Bearer " + token }
  });
  const campanhas = await res.json();

  const lista = document.getElementById("listaCampanhas");
  lista.innerHTML = "";
  campanhas.forEach(c => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between";
    li.innerHTML = `
      ${c.nome}
      <button class="btn btn-primary btn-sm" onclick="gerarRelatorio(${c.id})">Relatório</button>`;
    lista.appendChild(li);
  });
}

async function gerarRelatorio(id) {
  const res = await fetch(API + "/resultados/relatorio/" + id, {
    headers: { "Authorization": "Bearer " + token }
  });
  const data = await res.json();

  const ctx = document.getElementById("grafico");
  new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Alcance", "Engajamento", "Cliques", "Leads"],
      datasets: [{
        label: "Resultado",
        data: [data.totalAlcance, data.totalEngajamento, data.totalCliques, data.totalLeads]
      }]
    }
  });
}

function logout() {
  localStorage.clear();
  window.location.href = "index.html";
}

listarCampanhas();
